const Blog = () => {
  return (
    <>
      <h1>Blog Component</h1>
    </>
  );
};
export default Blog;
